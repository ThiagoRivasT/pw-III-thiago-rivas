const form = document.querySelector("#form")
const inputnome = document.querySelector("#inputnome")
const inputsobrenome = document.querySelector("#inputsobrenome")
const inputidade = document.querySelector("#inputidade")
const inputemail = document.querySelector("#email")
const mensagem = document.querySelector("#mensagem")

form.addEventListener("submit", (event) => {
event.preventDefault();

if(inputnome.value ===""){
    alert("preencha nome");
    return;
}

if(inputsobrenome.value ===""){
    alert("preencha sobrenome");
    return;
}

if(inputidade.value ===""){
    alert("preencha idade");
    return;
}

if(email.value ===""){
    alert("preencha email");
    return;
}

if(mensagem.value ===""){
    alert("preencha mensagem");
    return;
}
    const valuenome = inputnome.value;
    console.log("Nome:"+valuenome);
    const valuesobre = inputsobrenome.value;
    console.log("Sobrenome:"+valuesobre);
    const valueidade = inputidade.value;
    console.log("Idade:"+valueidade);
    const valueemail = email.value;
    console.log("Email:"+valueemail);
    const valuemensagem = mensagem.value;
    console.log("Mensagem:"+valuemensagem);
stop;
})
